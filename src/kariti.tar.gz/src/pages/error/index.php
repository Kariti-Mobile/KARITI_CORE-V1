<?php
	session_start();

	echo '<pre>';
	echo $_SESSION['error'];
	echo '<pre>';
?>
