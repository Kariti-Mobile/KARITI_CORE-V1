<!DOCTYPE html>
<html>
<head>
<title>Kariti Web</title>
<meta http-equiv="Refresh" content="0; url='src/pages/login/index.php'" />
</head>
<body>
Redirecionando...
</body>
</html>
