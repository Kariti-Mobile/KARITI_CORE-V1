import os
import os.path
import sys

path = sys.argv[1]
os.unlink(path)
